"""TinkClaw — Python SDK for real-time trading signals."""

from tinkclaw.client import TinkClaw
from tinkclaw.stream import StreamClient

__version__ = "0.1.1"
__all__ = ["TinkClaw", "StreamClient"]
